package com.cg.fmanage.exception;

public class FacultyNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

}
